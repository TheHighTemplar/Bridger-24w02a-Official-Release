Start the server by go to the terminal and type:
node server.js
the server will start at https://localhost:3001